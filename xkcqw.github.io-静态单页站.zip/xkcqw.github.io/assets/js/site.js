/* ==========================================================================
   XKCQW 传奇发布网站 — 单页应用交互
   路由：#/  首页   #/post/<slug>   #/cat/<slug>   #/tag/<标签>   #<锚点>
   无依赖、无框架，全部内容已在 HTML 中预渲染，搜索引擎可直接读取正文
   ========================================================================== */
(function () {
  "use strict";

  var homeView = document.getElementById("homeView");
  var postView = document.getElementById("postView");
  var posts = Array.prototype.slice.call(document.querySelectorAll(".post"));
  var nav = document.getElementById("mainNav");
  var navBtn = document.getElementById("navBtn");
  var searchBtn = document.getElementById("searchBtn");
  var input = document.getElementById("q");
  var grid = document.getElementById("allGrid");
  var cards = grid ? Array.prototype.slice.call(grid.querySelectorAll(".card")) : [];
  var chips = Array.prototype.slice.call(document.querySelectorAll(".chip"));
  var resultLine = document.getElementById("resultLine");
  var emptyEl = document.getElementById("empty");
  var progress = document.getElementById("progress");
  var toTop = document.getElementById("toTop");
  var toastEl = document.getElementById("toast");
  var yearEl = document.getElementById("year");

  var metaDesc = document.querySelector('meta[name="description"]');
  var metaKw = document.querySelector('meta[name="keywords"]');
  var ogTitle = document.querySelector('meta[property="og:title"]');
  var ogDesc = document.querySelector('meta[property="og:description"]');
  var ogUrl = document.querySelector('meta[property="og:url"]');

  var base = {
    title: document.title,
    desc: metaDesc ? metaDesc.content : "",
    kw: metaKw ? metaKw.content : ""
  };

  var state = { cat: "all", tag: "", q: "" };
  var lastType = "home";

  /* ------------------------------------------------------------ 工具函数 */
  function decode(v) {
    try { return decodeURIComponent(v); } catch (e) { return v; }
  }

  var toastTimer;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.hidden = false;
    requestAnimationFrame(function () { toastEl.classList.add("show"); });
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toastEl.classList.remove("show");
      setTimeout(function () { toastEl.hidden = true; }, 220);
    }, 1800);
  }

  function setMeta(title, desc) {
    document.title = title;
    if (metaDesc) metaDesc.content = desc;
    if (ogTitle) ogTitle.content = title;
    if (ogDesc) ogDesc.content = desc;
  }

  function scrollToEl(id) {
    var el = document.getElementById(id);
    if (!el) return;
    var top = el.getBoundingClientRect().top + window.pageYOffset - 78;
    window.scrollTo({ top: top, behavior: "smooth" });
  }

  /* ---------------------------------------------------------------- 路由 */
  function parseHash() {
    var raw = (location.hash || "").replace(/^#/, "");
    if (raw.indexOf("/post/") === 0) return { type: "post", slug: decode(raw.slice(6)) };
    if (raw.indexOf("/cat/") === 0) return { type: "cat", slug: decode(raw.slice(5)) };
    if (raw.indexOf("/tag/") === 0) return { type: "tag", tag: decode(raw.slice(5)) };
    if (raw.indexOf("/view/") === 0) return { type: "anchor", id: raw.slice(6) };
    if (raw === "" || raw === "/") return { type: "home" };
    return { type: "anchor", id: raw };
  }

  function setNavActive(key) {
    Array.prototype.forEach.call(document.querySelectorAll("[data-nav]"), function (a) {
      a.classList.toggle("is-active", a.getAttribute("data-nav") === key);
    });
  }

  function showHome() {
    if (postView) postView.hidden = true;
    if (homeView) homeView.hidden = false;
    posts.forEach(function (p) { p.hidden = true; });
    document.body.classList.remove("post-mode");
  }

  function showPost(slug) {
    var target = document.getElementById("post-" + slug);
    if (!target) return false;
    homeView.hidden = true;
    postView.hidden = false;
    posts.forEach(function (p) { p.hidden = p !== target; });
    document.body.classList.add("post-mode");

    var title = target.getAttribute("data-title") || "";
    var desc = target.getAttribute("data-desc") || base.desc;
    setMeta(title + " - " + base.title.split("_")[0], desc);
    if (metaKw) {
      var tags = target.getAttribute("data-tags") || "";
      metaKw.content = tags + ",传奇发布网站";
    }
    if (ogUrl) ogUrl.content = location.href.split("#")[0] + "#/post/" + slug;

    setNavActive(target.getAttribute("data-cat") || "");
    window.scrollTo({ top: 0, behavior: "auto" });

    var h1 = target.querySelector("h1");
    if (h1) {
      h1.setAttribute("tabindex", "-1");
      h1.focus({ preventScroll: true });
    }
    updateProgress();
    updateToc();
    return true;
  }

  function render() {
    var r = parseHash();

    if (r.type === "post" && showPost(r.slug)) {
      lastType = "post";
      closeNav();
      return;
    }

    var fromPost = lastType === "post";
    showHome();
    lastType = "home";
    closeNav();

    if (r.type === "cat") {
      state.tag = "";
      state.q = "";
      if (input) input.value = "";
      setChip(r.slug);
      setNavActive(r.slug);
      applyFilter();
      scrollToEl("all");
    } else if (r.type === "tag") {
      state.q = "";
      if (input) input.value = "";
      setChip("all");
      state.tag = r.tag;
      setNavActive("home");
      applyFilter();
      scrollToEl("all");
    } else if (r.type === "anchor") {
      setNavActive(r.id === "faq" ? "faq" : "home");
      scrollToEl(r.id);
    } else {
      setChip("all");
      setNavActive("home");
      applyFilter();
      if (fromPost) window.scrollTo({ top: 0, behavior: "auto" });
    }
  }

  /* ------------------------------------------------------------ 筛选搜索 */
  function setChip(slug) {
    state.cat = slug;
    chips.forEach(function (c) {
      c.classList.toggle("is-active", c.getAttribute("data-filter") === slug);
    });
  }

  function applyFilter() {
    if (!cards.length) return;
    var q = state.q.trim().toLowerCase();
    var shown = 0;

    cards.forEach(function (card) {
      var okCat = state.cat === "all" || card.getAttribute("data-cat") === state.cat;
      var okTag = !state.tag || ("," + (card.getAttribute("data-tags") || "") + ",").indexOf("," + state.tag + ",") > -1;
      var okQ = !q || (card.getAttribute("data-search") || "").toLowerCase().indexOf(q) > -1;
      var visible = okCat && okTag && okQ;
      card.hidden = !visible;
      if (visible) shown++;
    });

    if (emptyEl) emptyEl.hidden = shown !== 0;

    if (resultLine) {
      if (state.tag) {
        resultLine.textContent = "标签「" + state.tag + "」· 找到 " + shown + " 篇";
      } else if (q) {
        resultLine.textContent = "关键词「" + state.q.trim() + "」· 找到 " + shown + " 篇";
      } else if (state.cat !== "all") {
        var active = chips.filter(function (c) { return c.classList.contains("is-active"); })[0];
        resultLine.textContent = (active ? active.textContent.replace(/\s*\d+\s*$/, "") : "") + "· 共 " + shown + " 篇";
      } else {
        resultLine.textContent = "共 " + shown + " 篇，按更新时间排序";
      }
    }
  }

  /* ------------------------------------------------------------ 阅读进度 */
  function updateProgress() {
    if (!progress) return;
    var showingPost = postView && !postView.hidden;
    if (!showingPost) { progress.style.width = "0%"; return; }
    var doc = document.documentElement;
    var max = doc.scrollHeight - window.innerHeight;
    var pct = max > 0 ? (window.pageYOffset / max) * 100 : 0;
    progress.style.width = Math.max(0, Math.min(100, pct)) + "%";
  }

  function updateToc() {
    var links = Array.prototype.slice.call(
      document.querySelectorAll('.post:not([hidden]) .toc-list a')
    );
    if (!links.length) return;
    var current = links[0];
    links.forEach(function (l) {
      var el = document.getElementById(l.getAttribute("data-toc"));
      if (el && el.getBoundingClientRect().top < 150) current = l;
    });
    links.forEach(function (l) { l.classList.toggle("is-on", l === current); });
  }

  var ticking = false;
  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      ticking = false;
      updateProgress();
      updateToc();
      if (toTop) toTop.hidden = window.pageYOffset < 520;
    });
  }

  /* ------------------------------------------------------------ 移动端菜单 */
  function openNav() {
    nav.classList.add("is-open");
    navBtn.setAttribute("aria-expanded", "true");
    navBtn.setAttribute("aria-label", "关闭菜单");
    document.body.classList.add("nav-open");
  }
  function closeNav() {
    if (!nav) return;
    nav.classList.remove("is-open");
    if (navBtn) {
      navBtn.setAttribute("aria-expanded", "false");
      navBtn.setAttribute("aria-label", "打开菜单");
    }
    document.body.classList.remove("nav-open");
  }

  /* ---------------------------------------------------------------- 事件 */
  if (navBtn) {
    navBtn.addEventListener("click", function () {
      if (nav.classList.contains("is-open")) closeNav(); else openNav();
    });
  }

  if (nav) {
    nav.addEventListener("click", function (e) {
      if (e.target.closest("a")) closeNav();
    });
  }

  if (searchBtn) {
    searchBtn.addEventListener("click", function () {
      if (postView && !postView.hidden) location.hash = "#/";
      setTimeout(function () {
        scrollToEl("all");
        if (input) input.focus({ preventScroll: true });
      }, 40);
    });
  }

  chips.forEach(function (chip) {
    chip.addEventListener("click", function () {
      state.tag = "";
      state.q = "";
      if (input) input.value = "";
      setChip(chip.getAttribute("data-filter"));
      applyFilter();
    });
  });

  if (input) {
    input.addEventListener("input", function () {
      state.q = input.value;
      state.tag = "";
      applyFilter();
    });
    input.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { input.value = ""; state.q = ""; applyFilter(); input.blur(); }
    });
  }

  document.addEventListener("click", function (e) {
    var toc = e.target.closest("[data-toc]");
    if (toc) {
      e.preventDefault();
      scrollToEl(toc.getAttribute("data-toc"));
      return;
    }
    var copy = e.target.closest("[data-copy]");
    if (copy) {
      e.preventDefault();
      var url = location.origin + location.pathname + copy.getAttribute("data-copy");
      var done = function () { toast("链接已复制，可以分享给朋友了"); };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(done, function () { fallbackCopy(url, done); });
      } else {
        fallbackCopy(url, done);
      }
    }
  });

  function fallbackCopy(text, cb) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.cssText = "position:fixed;top:-1000px;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand("copy"); cb(); } catch (err) { toast("复制失败，请手动复制地址栏链接"); }
    document.body.removeChild(ta);
  }

  if (toTop) {
    toTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeNav();
  });

  window.addEventListener("resize", function () {
    if (window.innerWidth > 900) closeNav();
  });

  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("hashchange", render);

  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  /* ---------------------------------------------------------------- 启动 */
  if (location.hash && !/^#(\/|$)/.test(location.hash)) {
    // 首次进入带锚点（如 #faq）：先渲染首页再滚动
    showHome();
  }
  render();
  applyFilter();
  updateProgress();
})();
