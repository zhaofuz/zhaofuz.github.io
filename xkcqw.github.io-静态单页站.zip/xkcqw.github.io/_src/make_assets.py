#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成站点静态图片资源（无需联网，字体使用系统字体）：
    assets/img/og-cover.png          1200x630  社交分享 / 结构化数据封面
    assets/img/apple-touch-icon.png  180x180   iOS 主屏图标

用法: python _src/make_assets.py
依赖: Pillow  +  系统中文字体（Windows: msyhbd.ttc / simhei.ttf）
"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "assets" / "img"
OUT.mkdir(parents=True, exist_ok=True)

FONT_CANDIDATES = [
    (r"C:\Windows\Fonts\msyhbd.ttc", 0),
    (r"C:\Windows\Fonts\msyh.ttc", 0),
    (r"C:\Windows\Fonts\simhei.ttf", 0),
    (r"C:\Windows\Fonts\NotoSansSC-VF.ttf", 0),
]

BG_TOP = (10, 12, 17)
BG_BOTTOM = (16, 21, 29)
GOLD = (231, 180, 99)
GOLD_LIGHT = (247, 215, 154)
TEXT = (233, 238, 246)
MUTED = (160, 173, 188)
DIM = (124, 136, 152)


def load_font(size):
    for path, index in FONT_CANDIDATES:
        try:
            return ImageFont.truetype(path, size, index=index)
        except Exception:
            continue
    raise SystemExit("找不到可用的中文字体，请修改 FONT_CANDIDATES")


def vgradient(size, top, bottom):
    w, h = size
    img = Image.new("RGB", (1, h))
    px = img.load()
    for y in range(h):
        t = y / max(1, h - 1)
        px[0, y] = tuple(round(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
    return img.resize((w, h))


def glow(canvas, center, radius, color, alpha=70):
    layer = Image.new("RGBA", (radius * 2, radius * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for i in range(28, 0, -1):
        r = radius * i / 28
        a = int(alpha * (1 - i / 28) ** 1.6)
        d.ellipse([radius - r, radius - r, radius + r, radius + r], fill=color + (a,))
    layer = layer.filter(ImageFilter.GaussianBlur(radius * 0.12))
    canvas.alpha_composite(layer, (int(center[0] - radius), int(center[1] - radius)))


def diamond(draw, cx, cy, r, color, width=3):
    draw.polygon([(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)],
                 outline=color, width=width)


def grid(canvas, step=60, color=(255, 255, 255, 9)):
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    w, h = canvas.size
    for x in range(0, w, step):
        d.line([(x, 0), (x, h)], fill=color)
    for y in range(0, h, step):
        d.line([(0, y), (w, y)], fill=color)
    canvas.alpha_composite(layer)


def gradient_text(canvas, xy, text, font, top_color, bottom_color):
    """把文字做成渐变填充，贴回画布。"""
    box = font.getbbox(text)
    tw, th = box[2] - box[0] + 8, box[3] - box[1] + 8
    mask = Image.new("L", (tw, th), 0)
    d = ImageDraw.Draw(mask)
    d.text((4 - box[0], 4 - box[1]), text, font=font, fill=255)
    grad = vgradient((tw, th), top_color, bottom_color).convert("RGBA")
    grad.putalpha(mask)
    canvas.alpha_composite(grad, (int(xy[0]), int(xy[1])))


def make_cover():
    W, H = 1200, 630
    canvas = vgradient((W, H), BG_TOP, BG_BOTTOM).convert("RGBA")
    grid(canvas, 60)
    glow(canvas, (170, 60), 420, GOLD, 58)
    glow(canvas, (1100, 600), 300, (217, 96, 63), 34)

    draw = ImageDraw.Draw(canvas)

    # 右侧装饰：菱形 + 印章式单字
    diamond(draw, 985, 262, 118, GOLD + (105,), 2)
    diamond(draw, 985, 262, 80, GOLD + (135,), 2)
    seal = Image.new("RGBA", (240, 240), (0, 0, 0, 0))
    sd = ImageDraw.Draw(seal)
    font_seal = load_font(104)
    box = font_seal.getbbox("传")
    sd.text((120 - (box[2] + box[0]) / 2, 120 - (box[3] + box[1]) / 2), "传",
            font=font_seal, fill=GOLD_LIGHT + (205,))
    canvas.alpha_composite(seal, (985 - 120, 262 - 120))

    # 右下角水印
    warm = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    wd = ImageDraw.Draw(warm)
    wd.text((1010, 430), "传奇", font=load_font(150), fill=GOLD + (14,))
    canvas.alpha_composite(warm)

    # 左侧文字
    draw.text((88, 92), "X K C Q W   ·   传 奇 发 布 网", font=load_font(26), fill=GOLD)
    draw.line([(88, 132), (198, 132)], fill=GOLD + (170,), width=2)

    gradient_text(canvas, (84, 168), "传奇发布网站", load_font(104), GOLD_LIGHT, (198, 140, 46))
    draw.text((88, 320), "版本资讯  ·  开区节奏  ·  玩法攻略", font=load_font(34), fill=MUTED)
    draw.text((88, 384), "24 篇原创长文 · 六大分类 · 手机电脑都能读", font=load_font(24), fill=DIM)

    draw.line([(88, 486), (1112, 486)], fill=(255, 255, 255, 22), width=1)
    draw.text((88, 512), "xkcqw.github.io", font=load_font(24), fill=GOLD)
    draw.text((88, 548), "静态单页站点 · 无需注册 · 打开即读", font=load_font(21), fill=DIM)

    out = OUT / "og-cover.png"
    canvas.convert("RGB").save(out, "PNG", optimize=True)
    print(f"[asset] {out}  {out.stat().st_size/1024:.1f} KB")


def make_icon():
    S = 180
    canvas = vgradient((S, S), (18, 22, 30), (10, 12, 17)).convert("RGBA")
    glow(canvas, (S / 2, S / 2), 120, GOLD, 46)
    draw = ImageDraw.Draw(canvas)
    diamond(draw, S / 2, S / 2, 74, GOLD + (200,), 3)
    diamond(draw, S / 2, S / 2, 60, GOLD + (90,), 1)
    font = load_font(86)
    box = font.getbbox("传")
    tw, th = box[2] - box[0], box[3] - box[1]
    draw.text(((S - tw) / 2 - box[0], (S - th) / 2 - box[1] - 2), "传", font=font, fill=GOLD_LIGHT)

    out = OUT / "apple-touch-icon.png"
    canvas.convert("RGB").save(out, "PNG", optimize=True)
    print(f"[asset] {out}  {out.stat().st_size/1024:.1f} KB")


if __name__ == "__main__":
    make_cover()
    make_icon()
