#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
站点自检：在部署前确认结构、链接、SEO 标签是否正常。

用法: python _src/verify.py
退出码 0 表示全部通过。
"""

import json
import re
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link",
        "meta", "param", "source", "track", "wbr"}

errors = []
warns = []


class Checker(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.ids = {}
        self.links = []
        self.metas = {}
        self.title = ""
        self.in_title = False
        self.ld = []
        self.in_ld = False
        self.h1 = 0
        self.articles = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag not in VOID:
            self.stack.append((tag, self.getpos()))
        if "id" in a:
            if a["id"] in self.ids:
                errors.append(f"重复 id: {a['id']}")
            self.ids[a["id"]] = tag
        if tag == "a" and a.get("href"):
            self.links.append((a["href"], a.get("class", "")))
        if tag == "meta":
            key = a.get("name") or a.get("property")
            if key:
                self.metas[key] = a.get("content", "")
        if tag == "title":
            self.in_title = True
        if tag == "script" and a.get("type") == "application/ld+json":
            self.in_ld = True
        if tag == "h1":
            self.h1 += 1
        if tag == "article" and a.get("class", "").startswith("post"):
            self.articles += 1

    def handle_endtag(self, tag):
        if tag in VOID:
            return
        if tag == "title":
            self.in_title = False
        if tag == "script":
            self.in_ld = False
        if not self.stack:
            errors.append(f"多余的结束标签 </{tag}>")
            return
        open_tag, pos = self.stack.pop()
        if open_tag != tag:
            errors.append(f"标签未闭合: <{open_tag}> 在 {pos} 处，被 </{tag}> 关闭")

    def handle_data(self, data):
        if self.in_title:
            self.title += data
        if self.in_ld:
            self.ld.append(data)


def check_file(path: Path):
    text = path.read_text(encoding="utf-8")
    parser = Checker()
    parser.feed(text)
    parser.close()

    if parser.stack:
        for tag, pos in parser.stack:
            errors.append(f"未闭合标签 <{tag}> at {pos}")

    # 站内文章链接必须有对应正文区块
    post_links = {h[len("#/post/"):] for h, _ in parser.links if h.startswith("#/post/")}
    post_ids = {i[5:] for i, t in parser.ids.items() if i.startswith("post-")}
    missing = post_links - post_ids
    if missing:
        errors.append(f"失效的文章链接: {sorted(missing)}")
    unused = post_ids - post_links
    if unused:
        warns.append(f"没有入口的文章: {sorted(unused)}")

    # 分类链接校验
    for href, _ in parser.links:
        if href.startswith("#/cat/"):
            slug = href[6:]
            if not re.match(r"^[a-z]+$", slug):
                errors.append(f"分类链接异常: {href}")
        if href.startswith("#") and not href.startswith("#/"):
            if href[1:] not in parser.ids:
                warns.append(f"锚点无对应元素: {href}")

    # SEO 必备项
    required = ["description", "keywords", "robots", "applicable-device",
                "mobile-agent", "renderer", "viewport", "theme-color"]
    for key in required:
        if not parser.metas.get(key):
            errors.append(f"缺少 meta: {key}")

    if "canonical" not in text:
        errors.append("缺少 canonical")
    if "og:title" not in parser.metas:
        errors.append("缺少 og:title")
    if len(parser.title) < 12:
        errors.append("标题过短")
    if len(parser.title) > 40:
        warns.append(f"标题较长({len(parser.title)}字): {parser.title}")
    if "传奇发布网站" not in parser.title:
        errors.append("标题未包含核心词“传奇发布网站”")
    if "传奇发布网站" not in parser.metas.get("keywords", ""):
        errors.append("keywords 未包含核心词")
    if len(parser.metas.get("description", "")) < 60:
        errors.append("description 过短")
    if len(parser.metas.get("description", "")) > 160:
        warns.append("description 偏长")

    if parser.articles < 20:
        errors.append(f"文章数量不足: {parser.articles}")

    # 结构化数据
    for blob in parser.ld:
        try:
            data = json.loads(blob)
        except json.JSONDecodeError as e:
            errors.append(f"JSON-LD 解析失败: {e}")
            continue
        types = [x.get("@type") for x in data.get("@graph", [])]
        for need in ("WebSite", "ItemList", "FAQPage", "BreadcrumbList"):
            if need not in types:
                errors.append(f"JSON-LD 缺少 {need}")

    return parser


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    index = ROOT / "index.html"
    if not index.exists():
        print("缺少 index.html，请先运行 python _src/build.py")
        return 1

    p = check_file(index)

    # 文件清单
    needed = ["index.html", "404.html", "robots.txt", "sitemap.xml",
              "site.webmanifest", "assets/css/site.css", "assets/js/site.js",
              "assets/img/favicon.svg", "assets/img/og-cover.png",
              "assets/img/apple-touch-icon.png", ".nojekyll"]
    for name in needed:
        if not (ROOT / name).exists():
            errors.append(f"缺少文件: {name}")

    # sitemap 校验
    sm = (ROOT / "sitemap.xml").read_text(encoding="utf-8")
    if "<urlset" not in sm or "xkcqw.github.io" not in sm:
        errors.append("sitemap.xml 内容异常")
    if sm.count("<url>") < 1:
        errors.append("sitemap.xml 没有 url 条目")

    # CSS / JS 括号平衡（粗检）
    css = (ROOT / "assets/css/site.css").read_text(encoding="utf-8")
    if css.count("{") != css.count("}"):
        errors.append(f"CSS 花括号不平衡: {css.count('{')} vs {css.count('}')}")
    js = (ROOT / "assets/js/site.js").read_text(encoding="utf-8")
    if js.count("{") != js.count("}"):
        errors.append("JS 花括号不平衡")
    if js.count("(") != js.count(")"):
        errors.append("JS 圆括号不平衡")

    # 输出
    size = index.stat().st_size
    print(f"index.html      {size/1024:.1f} KB")
    print(f"title           {p.title}")
    print(f"description     {p.metas.get('description','')[:60]}…")
    print(f"文章区块        {p.articles} 个")
    print(f"唯一 id         {len(p.ids)} 个")
    print(f"站内链接        {len(p.links)} 条")
    print(f"JSON-LD 块      {len(p.ld)} 个")
    print(f"h1 数量         {p.h1}（单页内多文章各有一个，属预期）")

    for w in warns:
        print(f"  ~ {w}")
    if errors:
        print("\n错误:")
        for e in errors:
            print(f"  x {e}")
        return 1
    print("\n全部检查通过 ✓")
    return 0


if __name__ == "__main__":
    sys.exit(main())
