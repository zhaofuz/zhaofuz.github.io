#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
XKCQW 传奇发布网站 —— 静态单页站点生成器

用法:
    python _src/build.py          # 在仓库根目录或任意位置执行均可
    python _src/build.py --check  # 只做内容自检，不写文件

输入:
    _src/content/site.json        站点配置（标题、关键词、描述、分类、FAQ、文案）
    _src/content/articles/*.md    Markdown 文章（带 front matter）

输出:
    index.html                    单页站点（首页 + 全部文章的完整正文）
    sitemap.xml                   站点地图
    site.webmanifest              PWA 清单
"""

import html
import json
import re
import sys
import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent          # _src
ROOT = BASE.parent                              # 站点根目录
CONTENT = BASE / "content"
ART_DIR = CONTENT / "articles"


# --------------------------------------------------------------------------
# 基础工具
# --------------------------------------------------------------------------
def esc(text: str) -> str:
    return html.escape(str(text), quote=True)


def strip_md(text: str) -> str:
    text = re.sub(r"^---.*?---\n", "", text, flags=re.S)
    text = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"[#>*`\-]", "", text)
    return text


def cjk_len(text: str) -> int:
    return len(re.findall(r"[\u4e00-\u9fff]", text))


def fmt_date(iso: str) -> str:
    y, m, d = (int(x) for x in iso.split("-"))
    return f"{y}年{m}月{d}日"


def inline(text: str) -> str:
    """行内标记：**粗体**、`代码`、[文字](链接)。先转义再替换，避免注入。"""
    t = esc(text)

    def link(m):
        label, href = m.group(1), m.group(2)
        if not re.match(r"^(#|https?://|mailto:)", href):
            return label
        return f'<a href="{href}">{label}</a>'

    t = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", link, t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    return t


# --------------------------------------------------------------------------
# 内容解析
# --------------------------------------------------------------------------
def parse_front_matter(raw: str):
    if not raw.startswith("---"):
        raise ValueError("缺少 front matter")
    end = raw.find("\n---", 3)
    if end == -1:
        raise ValueError("front matter 未闭合")
    head = raw[3:end].strip()
    body = raw[end + 4:].lstrip("\n")

    meta = {}
    for line in head.splitlines():
        if not line.strip():
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        meta[key] = value

    for required in ("title", "category", "date", "tags", "excerpt"):
        if required not in meta or not meta[required]:
            raise ValueError(f"front matter 缺少字段: {required}")
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", meta["date"]):
        raise ValueError(f"日期格式错误: {meta['date']}")
    return meta, body


def render_body(md: str, slug: str):
    """极简 Markdown → HTML：段落 / h2 / h3 / 列表 / 引用块。"""
    blocks = re.split(r"\n\s*\n", md.strip())
    out, toc = [], []
    h2_idx = 0

    for block in blocks:
        block = block.strip()
        if not block:
            continue

        if block.startswith("### "):
            text = block[4:].strip()
            hid = f"{slug}-s{h2_idx}-{len(toc)}"
            toc.append((3, text, hid))
            out.append(f'<h3 id="{hid}">{inline(text)}</h3>')

        elif block.startswith("## "):
            text = block[3:].strip()
            h2_idx += 1
            hid = f"{slug}-s{h2_idx}"
            toc.append((2, text, hid))
            out.append(f'<h2 id="{hid}">{inline(text)}</h2>')

        elif block.startswith(">"):
            rows = [re.sub(r"^>\s?", "", line).strip() for line in block.splitlines()]
            rows = [r for r in rows if r]
            inner = "".join(f"<p>{inline(r)}</p>" for r in rows)
            out.append(f'<blockquote class="tip">{inner}</blockquote>')

        elif re.match(r"^[-*]\s+", block):
            items = [re.sub(r"^[-*]\s+", "", line).strip()
                     for line in block.splitlines() if line.strip()]
            out.append("<ul>" + "".join(f"<li>{inline(i)}</li>" for i in items) + "</ul>")

        elif re.match(r"^\d+[.、]\s+", block):
            items = [re.sub(r"^\d+[.、]\s+", "", line).strip()
                     for line in block.splitlines() if line.strip()]
            out.append("<ol>" + "".join(f"<li>{inline(i)}</li>" for i in items) + "</ol>")

        else:
            text = re.sub(r"\s*\n\s*", "", block)
            out.append(f"<p>{inline(text)}</p>")

    return "\n".join(out), toc


def load_articles(categories):
    cat_names = {c["slug"]: c["name"] for c in categories}
    items = []
    for path in sorted(ART_DIR.glob("*.md")):
        raw = path.read_text(encoding="utf-8")
        meta, body = parse_front_matter(raw)
        slug = path.stem
        cat = meta["category"].strip()
        if cat not in cat_names:
            raise ValueError(f"{path.name}: 未知分类 {cat}")
        body_html, toc = render_body(body, slug)
        chars = cjk_len(strip_md(body))
        tags = [t.strip() for t in meta["tags"].replace("，", ",").split(",") if t.strip()]
        items.append({
            "slug": slug,
            "title": meta["title"],
            "category": cat_names[cat],
            "cat_slug": cat,
            "date": meta["date"],
            "tags": tags,
            "excerpt": meta["excerpt"],
            "body": body_html,
            "toc": toc,
            "chars": chars,
            "minutes": max(2, round(chars / 400)),
            "updated": meta.get("updated", meta["date"]),
        })
    items.sort(key=lambda a: (a["date"], a["slug"]), reverse=True)
    return items


# --------------------------------------------------------------------------
# 片段渲染
# --------------------------------------------------------------------------
def render_card(a, extra=""):
    tag_attr = " ".join(a["tags"])
    search = f'{a["title"]} {a["excerpt"]} {tag_attr} {a["category"]}'
    return f"""<article class="card{extra}" data-cat="{a['cat_slug']}" data-tags="{esc(','.join(a['tags']))}" data-search="{esc(search)}">
  <a class="card-hit" href="#/post/{a['slug']}">
    <span class="card-cat">{a['category']}</span>
    <h3 class="card-title">{esc(a['title'])}</h3>
    <p class="card-ex">{esc(a['excerpt'])}</p>
    <span class="card-foot">
      <time datetime="{a['date']}">{fmt_date(a['date'])}</time>
      <span class="dot" aria-hidden="true">·</span>
      <span>{a['minutes']} 分钟</span>
      <span class="card-more" aria-hidden="true">阅读</span>
    </span>
  </a>
</article>"""


def render_row(a, idx=None):
    num = f'<span class="rank-n">{idx}</span>' if idx else ""
    return f"""<li class="row">
  {num}<a class="row-hit" href="#/post/{a['slug']}">
    <span class="row-cat">{a['category']}</span>
    <span class="row-title">{esc(a['title'])}</span>
    <time class="row-date" datetime="{a['date']}">{a['date'][5:].replace('-', '/')}</time>
  </a>
</li>"""


def render_toc(toc, slug):
    if not toc:
        return ""
    rows = []
    for level, text, hid in toc:
        rows.append(f'<li class="toc-l{level}"><a href="#{hid}" data-toc="{hid}">{inline(text)}</a></li>')
    return f"""<aside class="toc" aria-label="本文目录">
  <p class="toc-h">本文目录</p>
  <ol class="toc-list">
    {''.join(rows)}
  </ol>
</aside>"""


def render_article(a, prev_a, next_a, related):
    toc_html = render_toc(a["toc"], a["slug"])
    tags_html = "".join(f'<a class="tag" href="#/tag/{esc(t)}">{esc(t)}</a>' for t in a["tags"])
    related_html = ""
    if related:
        cards = "".join(render_card(r) for r in related)
        related_html = f"""<section class="related">
  <h2 class="sec-h sm">继续阅读</h2>
  <div class="card-grid three">{cards}</div>
</section>"""

    nav_html = ""
    if prev_a or next_a:
        left = (f'<a class="pn pn-prev" href="#/post/{prev_a["slug"]}"><span>上一篇</span><strong>{esc(prev_a["title"])}</strong></a>'
                if prev_a else '<span class="pn pn-empty"></span>')
        right = (f'<a class="pn pn-next" href="#/post/{next_a["slug"]}"><span>下一篇</span><strong>{esc(next_a["title"])}</strong></a>'
                 if next_a else '<span class="pn pn-empty"></span>')
        nav_html = f'<nav class="post-nav" aria-label="文章翻页">{left}{right}</nav>'

    return f"""<article class="post" id="post-{a['slug']}" data-cat="{a['cat_slug']}" data-title="{esc(a['title'])}" data-desc="{esc(a['excerpt'])}" data-tags="{esc(','.join(a['tags']))}" hidden>
  <nav class="crumbs" aria-label="面包屑">
    <a href="#/">首页</a><span class="sep">/</span><a href="#/cat/{a['cat_slug']}">{a['category']}</a><span class="sep">/</span><span aria-current="page">正文</span>
  </nav>
  <header class="post-head">
    <a class="post-cat" href="#/cat/{a['cat_slug']}">{a['category']}</a>
    <h1>{esc(a['title'])}</h1>
    <p class="post-lead">{esc(a['excerpt'])}</p>
    <div class="post-meta">
      <time datetime="{a['date']}">{fmt_date(a['date'])}</time>
      <span class="dot">·</span><span>约 {a['chars']} 字</span>
      <span class="dot">·</span><span>阅读 {a['minutes']} 分钟</span>
      <span class="dot">·</span><span>分类 {a['category']}</span>
    </div>
  </header>
  <div class="post-grid">
    {toc_html}
    <div class="post-body">
{a['body']}
      <div class="post-tags">{tags_html}</div>
      <div class="post-share">
        <button class="btn ghost sm" type="button" data-copy="#/post/{a['slug']}">复制本文链接</button>
        <a class="btn ghost sm" href="#/">返回首页</a>
      </div>
    </div>
  </div>
  {nav_html}
  {related_html}
</article>"""


def render_faq(faq):
    rows = []
    for i, item in enumerate(faq, 1):
        open_attr = " open" if i == 1 else ""
        rows.append(f"""<details class="faq-item"{open_attr}>
  <summary><span class="faq-n">{i:02d}</span>{esc(item['q'])}</summary>
  <div class="faq-a"><p>{esc(item['a'])}</p></div>
</details>""")
    return "\n".join(rows)


# --------------------------------------------------------------------------
# 页面
# --------------------------------------------------------------------------
def build_page(site, categories, articles):
    cat_by_slug = {c["slug"]: c for c in categories}
    url = site["url"]
    today = datetime.date.today().isoformat()

    by_slug = {a["slug"]: a for a in articles}
    featured = [by_slug[s] for s in [
        "what-is-chuanqi-publish-site",
        "newbie-day-one-guide",
        "three-classes-how-to-choose",
        "guild-war-guide",
    ] if s in by_slug]
    hot = [by_slug[s] for s in [
        "warrior-guide", "mage-guide", "taoist-guide",
        "treasure-farming-routes", "how-to-judge-a-version", "pre-open-checklist",
    ] if s in by_slug]
    latest = articles[:6]

    counts = {c["slug"]: 0 for c in categories}
    for a in articles:
        counts[a["cat_slug"]] += 1

    # ---- 头部导航 ----
    nav_items = ['<a href="#/" data-nav="home" class="is-active">首页</a>']
    for c in categories:
        nav_items.append(f'<a href="#/cat/{c["slug"]}" data-nav="{c["slug"]}">{c["name"]}</a>')
    nav_items.append('<a href="#/view/faq" data-nav="faq">常见问题</a>')
    nav_html = "\n        ".join(nav_items)

    # ---- 首屏 ----
    stats_html = "".join(
        f'<li><b>{esc(s["value"])}</b><span>{esc(s["label"])}</span></li>' for s in site["stats"]
    )

    # ---- 编辑推荐 ----
    featured_html = "".join(render_card(a, " feature") for a in featured)

    # ---- 分类 ----
    cat_tiles = []
    for c in categories:
        cat_tiles.append(f"""<a class="tile" href="#/cat/{c['slug']}" data-cat="{c['slug']}">
  <span class="tile-top"><span class="tile-name">{c['name']}</span><span class="tile-n">{counts[c['slug']]:02d}</span></span>
  <span class="tile-desc">{esc(c['desc'])}</span>
  <span class="tile-go" aria-hidden="true">查看分类 →</span>
</a>""")

    # ---- 全部文章 ----
    filters = ['<button class="chip is-active" type="button" data-filter="all">全部 <i>' + str(len(articles)) + '</i></button>']
    for c in categories:
        filters.append(f'<button class="chip" type="button" data-filter="{c["slug"]}">{c["name"]} <i>{counts[c["slug"]]}</i></button>')
    filters_html = "".join(filters)
    cards_html = "\n".join(render_card(a) for a in articles)

    # ---- 最新 / 热门 ----
    latest_html = "".join(render_row(a) for a in latest)
    hot_html = "".join(render_row(a, i + 1) for i, a in enumerate(hot))

    # ---- 标签云 ----
    tag_count = {}
    for a in articles:
        for t in a["tags"]:
            tag_count[t] = tag_count.get(t, 0) + 1
    top_tags = sorted(tag_count.items(), key=lambda kv: (-kv[1], kv[0]))[:16]
    tags_html = "".join(f'<a class="tag" href="#/tag/{esc(t)}">{esc(t)}</a>' for t, _ in top_tags)

    # ---- 文章视图 ----
    ordered = sorted(articles, key=lambda a: (a["date"], a["slug"]), reverse=True)
    posts_html = []
    for i, a in enumerate(ordered):
        prev_a = ordered[i - 1] if i > 0 else None
        next_a = ordered[i + 1] if i + 1 < len(ordered) else None
        pool = [x for x in ordered if x["cat_slug"] == a["cat_slug"] and x["slug"] != a["slug"]]
        if len(pool) < 3:
            pool += [x for x in ordered if x["slug"] != a["slug"] and x not in pool]
        posts_html.append(render_article(a, prev_a, next_a, pool[:3]))

    # ---- 结构化数据 ----
    graph = [
        {
            "@type": "WebSite",
            "@id": f"{url}/#website",
            "url": f"{url}/",
            "name": site["brand"],
            "alternateName": [site["siteName"], "传奇发布网", "传奇版本资讯站"],
            "description": site["description"],
            "inLanguage": "zh-CN",
            "publisher": {
                "@type": "Organization",
                "name": site["brand"],
                "url": f"{url}/",
            },
        },
        {
            "@type": "CollectionPage",
            "@id": f"{url}/#webpage",
            "url": f"{url}/",
            "name": site["title"],
            "isPartOf": {"@id": f"{url}/#website"},
            "inLanguage": "zh-CN",
            "about": {"@type": "Thing", "name": site["siteName"]},
            "primaryImageOfPage": {"@type": "ImageObject", "url": f"{url}/assets/img/og-cover.png"},
        },
        {
            "@type": "BreadcrumbList",
            "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "首页", "item": f"{url}/"},
                {"@type": "ListItem", "position": 2, "name": "传奇发布网站", "item": f"{url}/"},
            ],
        },
        {
            "@type": "ItemList",
            "name": f"{site['siteName']}全部文章",
            "numberOfItems": len(articles),
            "itemListElement": [
                {
                    "@type": "ListItem",
                    "position": i + 1,
                    "name": a["title"],
                    "url": f"{url}/#/post/{a['slug']}",
                }
                for i, a in enumerate(ordered)
            ],
        },
        {
            "@type": "FAQPage",
            "mainEntity": [
                {
                    "@type": "Question",
                    "name": q["q"],
                    "acceptedAnswer": {"@type": "Answer", "text": q["a"]},
                }
                for q in site["faq"]
            ],
        },
    ]
    ld_json = json.dumps({"@context": "https://schema.org", "@graph": graph},
                         ensure_ascii=False, separators=(",", ":"))

    about_paras = "".join(f"<p>{esc(p)}</p>" for p in site["about"]["paras"])

    head = f"""<!DOCTYPE html>
<html lang="{site['lang']}" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{esc(site['title'])}</title>
<meta name="keywords" content="{esc(site['keywords'])}">
<meta name="description" content="{esc(site['description'])}">
<meta name="author" content="{esc(site['author'])}">
<meta name="copyright" content="{esc(site['brand'])}">
<meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1">
<meta name="googlebot" content="index,follow,max-image-preview:large,max-snippet:-1">
<meta name="applicable-device" content="pc,mobile">
<meta name="mobile-agent" content="format=html5;url={url}/">
<meta name="renderer" content="webkit">
<meta name="force-rendering" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no,email=no">
<meta name="theme-color" content="#0b0d12">
<!-- 百度站长平台验证：拿到验证码后取消下面这行注释并替换内容 -->
<!-- <meta name="baidu-site-verification" content="codeva-xxxxxxxxxx"> -->
<link rel="canonical" href="{url}/">
<link rel="alternate" media="only screen and (max-width:640px)" href="{url}/">
<link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">
<link rel="manifest" href="site.webmanifest">
<link rel="stylesheet" href="assets/css/site.css">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{esc(site['brand'])}">
<meta property="og:locale" content="zh_CN">
<meta property="og:title" content="{esc(site['title'])}">
<meta property="og:description" content="{esc(site['description'])}">
<meta property="og:url" content="{url}/">
<meta property="og:image" content="{url}/assets/img/og-cover.png">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{esc(site['title'])}">
<meta name="twitter:description" content="{esc(site['description'])}">
<meta name="twitter:image" content="{url}/assets/img/og-cover.png">
<script type="application/ld+json">{ld_json}</script>
</head>"""

    # 百度自动推送：默认注释掉，拿到站长平台 token 后启用
    push_snippet = """<!-- 百度自动推送（可选）：把下面的 token 换成你在百度站长平台拿到的推送密钥，再取消整段注释
<script>
(function(){"use strict";
var bp=document.createElement("script");
var url=window.location.protocol==="https:"?"https://zz.bdstatic.com/linksubmit/push.js":"http://push.zhanzhang.baidu.com/push.js";
bp.src=url;var s=document.getElementsByTagName("script")[0];s.parentNode.insertBefore(bp,s);
})();
</script>
-->"""

    # 禁用 JavaScript 时的降级：直接顺序展示全部文章
    noscript_block = (
        '<noscript>\n'
        '  <p style="max-width:1180px;margin:14px auto;padding:10px 16px;border:1px solid rgba(231,180,99,.35);'
        'border-radius:8px;font-size:13px;color:#e7b463">'
        '当前浏览器未启用 JavaScript：全部文章仍可在下方顺序阅读，分类筛选、站内搜索与阅读进度暂不可用。'
        '</p>\n'
        '  <style>#postView[hidden],.post[hidden]{display:block!important}'
        '#postView{margin-top:26px;border-top:1px solid rgba(255,255,255,.08)}</style>\n'
        '</noscript>'
    )

    body = f"""<body>
<a class="skip" href="#main">跳到正文</a>

{noscript_block}

<header class="site-head">
  <div class="wrap head-in">
    <a class="brand" href="#/" aria-label="{esc(site['brand'])} 首页">
      <span class="brand-mark" aria-hidden="true">
        <svg viewBox="0 0 32 32" width="26" height="26" focusable="false">
          <defs><linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#f6d79a"/><stop offset="1" stop-color="#c08c2e"/>
          </linearGradient></defs>
          <path d="M16 2 30 16 16 30 2 16Z" fill="none" stroke="url(#g1)" stroke-width="1.6"/>
          <path d="M16 8.5 23.5 16 16 23.5 8.5 16Z" fill="url(#g1)" opacity=".22"/>
          <path d="M16 9.5v13M11.5 14.5 16 9.5l4.5 5" fill="none" stroke="url(#g1)" stroke-width="1.6" stroke-linecap="round"/>
        </svg>
      </span>
      <span class="brand-text"><b>{esc(site['brandMark'])}</b><i>传奇发布网</i></span>
    </a>
    <nav class="main-nav" id="mainNav" aria-label="主导航">
        {nav_html}
    </nav>
    <div class="head-tools">
      <button class="ico-btn" id="searchBtn" type="button" aria-label="搜索站内文章">
        <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m16 16 4.5 4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      </button>
      <button class="ico-btn nav-btn" id="navBtn" type="button" aria-label="打开菜单" aria-expanded="false" aria-controls="mainNav">
        <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      </button>
    </div>
  </div>
  <div class="read-progress" id="progress" aria-hidden="true"></div>
</header>

<main id="main">
  <div class="view" id="homeView">
    <section class="hero">
      <div class="wrap">
        <div class="hero-in">
          <p class="eyebrow">{esc(site['heroEyebrow'])}</p>
          <h1>{esc(site['siteName'])}<span class="h1-sub">版本资讯 · 开区节奏 · 玩法攻略</span></h1>
          <p class="hero-lead">{esc(site['heroLead'])}</p>
          <div class="hero-cta">
            <a class="btn" href="#all">浏览全部文章</a>
            <a class="btn ghost" href="#/cat/xinshou">从新手入门开始</a>
          </div>
          <ul class="hero-stats">{stats_html}</ul>
          <p class="hero-note">{esc(site['heroNote'])}</p>
        </div>
      </div>
    </section>

    <nav class="quick-nav" aria-label="分类快捷入口">
      <div class="wrap quick-in">
        <a href="#/cat/banben">版本资讯</a>
        <a href="#/cat/kaiqu">开区指南</a>
        <a href="#/cat/xinshou">新手入门</a>
        <a href="#/cat/zhiye">职业攻略</a>
        <a href="#/cat/wanfa">玩法技巧</a>
        <a href="#/cat/changshi">安全与常识</a>
      </div>
    </nav>

    <div class="wrap home-grid">
      <div class="home-main">

        <section class="sec" id="picks">
          <div class="sec-head">
            <h2 class="sec-h">编辑推荐</h2>
            <p class="sec-sub">先读这四篇，能省下大量试错时间</p>
          </div>
          <div class="card-grid four">
{featured_html}
          </div>
        </section>

        <section class="sec" id="cats">
          <div class="sec-head">
            <h2 class="sec-h">按分类浏览</h2>
            <p class="sec-sub">六个方向，各取所需</p>
          </div>
          <div class="tile-grid">
{''.join(cat_tiles)}
          </div>
        </section>

        <section class="sec" id="all">
          <div class="sec-head">
            <h2 class="sec-h">全部文章</h2>
            <p class="sec-sub">共 {len(articles)} 篇 · 站内搜索与分类筛选</p>
          </div>
          <div class="toolbar">
            <div class="chips" id="chips">
              {filters_html}
            </div>
            <div class="search-box">
              <label class="sr-only" for="q">搜索文章</label>
              <input id="q" type="search" placeholder="搜索标题、标签、关键词…" autocomplete="off">
            </div>
          </div>
          <p class="result-line" id="resultLine" role="status" aria-live="polite"></p>
          <div class="card-grid" id="allGrid">
{cards_html}
          </div>
          <p class="empty" id="empty" hidden>没有匹配的文章，换个关键词试试，或点“全部”回到完整列表。</p>
        </section>

        <section class="sec" id="faq">
          <div class="sec-head">
            <h2 class="sec-h">常见问题</h2>
            <p class="sec-sub">关于本站与传奇类游戏的常见疑问</p>
          </div>
          <div class="faq">
{render_faq(site['faq'])}
          </div>
        </section>

        <section class="sec" id="about">
          <div class="sec-head">
            <h2 class="sec-h">{esc(site['about']['title'])}</h2>
            <p class="sec-sub">站点定位与内容原则</p>
          </div>
          <div class="about">
{about_paras}
            <ul class="facts">
              <li><b>{len(articles)}</b><span>篇文章</span></li>
              <li><b>{len(categories)}</b><span>个分类</span></li>
              <li><b>{len(top_tags)}+</b><span>个标签</span></li>
              <li><b>{today}</b><span>最近构建</span></li>
            </ul>
          </div>
        </section>

      </div>

      <aside class="home-side" aria-label="侧栏">
        <section class="panel">
          <h2 class="panel-h">最新更新</h2>
          <ul class="rows">
            {latest_html}
          </ul>
        </section>

        <section class="panel">
          <h2 class="panel-h">热门排行</h2>
          <ul class="rows rank">
            {hot_html}
          </ul>
        </section>

        <section class="panel">
          <h2 class="panel-h">热门标签</h2>
          <div class="tags">{tags_html}</div>
        </section>

        <section class="panel note">
          <h2 class="panel-h">阅读提示</h2>
          <p>本站只做信息整理与经验分享，不提供客户端下载、不设充值入口。文中数值来自玩家公开讨论，不同版本差异较大，请以游戏内实际设定为准。</p>
        </section>
      </aside>
    </div>
  </div>

  <div class="view" id="postView" hidden>
    <div class="wrap post-stage" id="postStage">
{chr(10).join(posts_html)}
    </div>
  </div>
</main>

<footer class="site-foot">
  <div class="wrap foot-grid">
    <div class="foot-brand">
      <p class="foot-name">{esc(site['brand'])}</p>
      <p class="foot-desc">把传奇类游戏的版本信息、开区节奏与玩法经验整理成可以读完的长文，帮玩家少走弯路。</p>
      <p class="foot-meta">{esc(site['buildInfo'])}</p>
    </div>
    <nav class="foot-nav" aria-label="页脚导航">
      <p class="foot-h">内容分类</p>
      <a href="#/cat/banben">版本资讯</a>
      <a href="#/cat/kaiqu">开区指南</a>
      <a href="#/cat/xinshou">新手入门</a>
      <a href="#/cat/zhiye">职业攻略</a>
      <a href="#/cat/wanfa">玩法技巧</a>
      <a href="#/cat/changshi">安全与常识</a>
    </nav>
    <nav class="foot-nav" aria-label="站点信息">
      <p class="foot-h">站点</p>
      <a href="#/">首页</a>
      <a href="#faq">常见问题</a>
      <a href="#about">关于本站</a>
      <a href="sitemap.xml">站点地图</a>
      <a href="robots.txt">robots</a>
    </nav>
  </div>
  <div class="wrap foot-note">
    <p class="disclaimer">{esc(site['disclaimer'])}</p>
    <p class="copy">© <span id="year">2026</span> {esc(site['brand'])} · {esc(site['footerNote'])}</p>
  </div>
</footer>

<button class="to-top" id="toTop" type="button" aria-label="回到顶部" hidden>
  <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 19V6m0 0-6 6m6-6 6 6" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>
</button>

<div class="toast" id="toast" role="status" aria-live="polite" hidden></div>

<script src="assets/js/site.js" defer></script>
{push_snippet}
</body>
</html>
"""
    return head + body


def build_sitemap(site, articles):
    """单页站点：真正的可抓取 URL 只有首页一个，
    分类与文章都在首页正文中，因此不提交带 # 的伪 URL（避免重复内容）。"""
    url = site["url"]
    today = datetime.date.today().isoformat()
    latest = max([a["date"] for a in articles] + [today])
    urls = [(f"{url}/", latest, "1.0", "daily")]
    body = "\n".join(
        f"  <url>\n    <loc>{loc}</loc>\n    <lastmod>{mod}</lastmod>\n"
        f"    <changefreq>{freq}</changefreq>\n    <priority>{prio}</priority>\n  </url>"
        for loc, mod, prio, freq in urls
    )
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
            f"{body}\n</urlset>\n")


def build_manifest(site):
    return json.dumps({
        "name": site["brand"],
        "short_name": site["brandMark"],
        "description": site["description"],
        "start_url": "./",
        "display": "standalone",
        "background_color": "#0b0d12",
        "theme_color": "#0b0d12",
        "lang": "zh-CN",
        "icons": [
            {"src": "assets/img/favicon.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any"},
        ],
    }, ensure_ascii=False, indent=2)


# --------------------------------------------------------------------------
# 自检
# --------------------------------------------------------------------------
def check(site, categories, articles):
    problems = []
    titles = {}
    with_kw = 0
    for a in articles:
        if a["title"] in titles:
            problems.append(f"标题重复: {a['title']}")
        titles[a["title"]] = a["slug"]
        if a["chars"] < 650:
            problems.append(f"字数偏少({a['chars']}): {a['slug']}")
        if "传奇发布网站" in (a["title"] + a["excerpt"] + a["body"]):
            with_kw += 1
        if len(a["tags"]) < 3:
            problems.append(f"标签少于3个: {a['slug']}")
    if with_kw < 8:
        problems.append(f"含核心词的文章偏少: {with_kw}")
    if len(articles) < 20:
        problems.append(f"文章数量偏少: {len(articles)}")
    for c in categories:
        n = sum(1 for a in articles if a["cat_slug"] == c["slug"])
        if n == 0:
            problems.append(f"分类无文章: {c['name']}")
    return problems


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    site = json.loads((CONTENT / "site.json").read_text(encoding="utf-8"))
    categories = site["categories"]
    articles = load_articles(categories)

    problems = check(site, categories, articles)
    for p in problems:
        print(f"  ! {p}")

    if "--check" in sys.argv:
        print(f"[check] 文章 {len(articles)} 篇，问题 {len(problems)} 项")
        return 0 if not problems else 1

    page = build_page(site, categories, articles)
    (ROOT / "index.html").write_text(page, encoding="utf-8")
    (ROOT / "sitemap.xml").write_text(build_sitemap(site, articles), encoding="utf-8")
    (ROOT / "site.webmanifest").write_text(build_manifest(site), encoding="utf-8")

    chars = sum(a["chars"] for a in articles)
    size = len(page.encode("utf-8"))
    print(f"[build] 文章 {len(articles)} 篇 / 分类 {len(categories)} 个 / 正文 {chars} 字")
    print(f"[build] index.html {size / 1024:.1f} KB  →  {ROOT / 'index.html'}")
    print(f"[build] sitemap.xml / site.webmanifest 已生成")
    if problems:
        print(f"[build] 自检提示 {len(problems)} 项（不阻塞构建）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
